#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

#define PWM_PIN 0
#define leftMotorBaseSpeed 25
#define rightMotorBaseSpeed 25
#define min_speed -50
#define max_speed 50

#endif // MAIN_H_INCLUDED
